1. Make sure sound library is imported

2. Run game
